App.controller('ContactController', [
    '$scope', '$http', 
    function ($scope, $http) {
      
    }
  ]);